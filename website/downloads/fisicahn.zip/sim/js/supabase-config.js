/**
 * Copia este archivo a supabase-config.js y rellena tus valores.
 *
 *   cp website/js/supabase-config.example.js website/js/supabase-config.js
 *
 * SOLO la anon/public key. NUNCA la service_role en el frontend ni en el repo.
 * En GitHub Pages usa secrets del workflow (ver .github/workflows/deploy-pages.yml).
 *
 * Dónde obtenerlas:
 *   Supabase Dashboard → Project Settings → API
 *   - Project URL  → url
 *   - anon public  → anonKey
 */
export default {
  /** Ej: https://xxxxxxxxxxxx.supabase.co */
  url: 'https://ntsryoridrtwoztokhcn.supabase.co',
  /** JWT anon public (empieza por eyJ...) */
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im50c3J5b3JpZHJ0d296dG9raGNuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM3MzUxMTMsImV4cCI6MjA5OTMxMTExM30.L2pfQRylQYiZzt7eof-9GGqIDQ1h3XhK_C8KyeraPzM',
  /** false fuerza modo solo-local aunque haya keys */
  enabled: true
};
