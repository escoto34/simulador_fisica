/**
 * Local — no commitear.
 */
export default {
  url: 'https://ntsryoridrtwoztokhcn.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im50c3J5b3JpZHJ0d296dG9raGNuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM3MzUxMTMsImV4cCI6MjA5OTMxMTExM30.L2pfQRylQYiZzt7eof-9GGqIDQ1h3XhK_C8KyeraPzM',
  enabled: true
};
